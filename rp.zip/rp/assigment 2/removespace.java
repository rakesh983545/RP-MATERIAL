package trainingday4;
import java.util.*;
public class removespace {
	
	
	public static void main(String ar[])
	{
		String str;
		String st="";
		String x;
		String p="";
		int i,j=0,k,a;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter sentence");
		str=sc.nextLine();
		for(i=0;i<str.length()-1;i++)
		{
			if(!(str.charAt(i)==' ' && str.charAt(i+1)==' '))
			{
				st+=str.charAt(i);
			}
		}
		if(!(str.charAt(str.length()-1)==' '))
			st+=str.charAt(str.length()-1);
		System.out.println("Input Word to be deleted and position in the sentence");
		System.out.println(st);
		x=sc.next();
		k=sc.nextInt();
		int zx=0;
		for(i=0;i<st.length();i++)
		{
			if(st.charAt(i)==' ')
			{
				j++;
				if(j==k-1)
				{
					zx=i;
					break;
				}
			}
			
		}
		System.out.println();
		for(i=0;i<st.length();i++)
		{
			if(i==zx)
			{
				i=i+x.length()+1;
			}
			System.out.print(st.charAt(i));
		}
		


		
		
		
		
		
	}
}
