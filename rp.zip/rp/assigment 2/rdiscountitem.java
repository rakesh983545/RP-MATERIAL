package trainingday4;
import java.util.*;
public class discount {
	public static void main(String args[])
	{
		int n,s,i,j;
		float newitem;
		float discount;
		float newitemprice;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter price of item");
		newitem=sc.nextFloat();
		discount=(float)0.35*newitem;
		newitemprice=newitem-discount;
		System.out.println("Price="+newitem+" discount="+discount+" discounted price="+newitemprice);
		
		
	}

}
