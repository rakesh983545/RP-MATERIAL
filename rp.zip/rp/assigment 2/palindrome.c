import java.util.Scanner;
public class palindrome{

     public static void main(String []args){
         int n,rev=0,rem,org;
         Scanner obj=new Scanner(System.in);
         System.out.println("enter n");
         n=obj.nextInt();
         org=n;
         while(n>0)
         {
             rem=n%10;
             rev=rev*10+rem;
             n=n/10;
         }
         if(org==rev)
          System.out.print("True");
          else
           System.out.print("False");
         
         
        //System.out.println("Hello World");
     }
}