package trainingday4;
import java.util.*;
public class duplicate {
	public static void main(String args[])
	{
		int i,j,k,n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter limit");
		n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter numbers in array");
		for(i=0;i<n;i++)
			a[i]=sc.nextInt();
		System.out.println("Enter k");
		k=sc.nextInt();
		for(i=0;i<n;i++)
		{
			for(j=0;j<n && j!=i;j++)
			{
				if((a[i]==a[j])&&(Math.abs(i-j)<=k)){
					System.out.println(a[i]);
					
				
			}
		}
	}

}
}
