/*Write a program to input a word from the user and remove the duplicate characters present in it.
Example:
INPUT – abcabcabc
OUTPUT – abc
INPUT – javaforschool
OUTPUT – javforschl
INPUT – Mississippi
OUTPUT – Misp*/
import java.util.*;
public class Remove
    {
    public static void main(String[] args)
    {
        String str;
        Scanner obj=new Scanner(System.in);
        str=obj.next();
        char ch;
        String ans="";
         
        for(int i=0; i<str.length(); i++)
        {
            ch = str.charAt(i);
            if(ch!=' ')
                ans = ans + ch;
            str= str.replace(ch,' '); 
        }
 
       System.out.println("Word after removing duplicate characters : " + ans);
    }
} 
