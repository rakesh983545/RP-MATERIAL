package trainingday4;
import java.util.*;
public class palinsort {
	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		String a[]=new String[10];
		String b[]=new String[10];
		int x[]=new int[10];
		int n=0,i,j;
		System.out.println("Enter 10 numbers");
		for(i=0;i<10;i++)
			a[i]=sc.next();
		palinsort ob=new palinsort();
		for(i=0;i<10;i++)
		{
			if(ob.rev(a[i]))
			{
				x[n]=ob.count(a[i]);
				b[n]=a[i];
				n++;
			}
		}
		String y[]=new String[n];
		int z[]=new int[n];
		int temp;
		String t="";
		for(i=0;i<n;i++)
		{
			y[i]=b[i];
			z[i]=x[i];
		}
		for (i = 0; i < n - 1; i++) 
        {
            
            for (j = 0; j < n - i - 1; j++) 
            {
                if (z[j] > z[j + 1]) 
                {
                   
                    temp = z[j];
                    z[j] =z[j + 1];
                    z[j + 1] = temp;
                    t=y[j];
                    y[j]=y[j+1];
                    y[j+1]=t;
                }
            }
        }
		for(i=0;i<n;i++)
		{
			System.out.println(y[i]);
		}


	}
		
	boolean rev(String a)
	{
		String st="";
		int i;
		for(i=a.length()-1;i>=0;i--)
			st+=a.charAt(i);
		if(st.equals(a)==true)
			return true;
			else
				return false;
	}
	int count(String st)
	{
		return st.length();
	}

}
