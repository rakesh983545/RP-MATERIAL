package trainingday4;

import java.util.*;
public class missingnumb{

     public static void main(String []args)
     {
         
         int i,n,sum=0;
       Scanner sc=new Scanner(System.in);
        System.out.println("Enter  n followed by numbers");
       n=sc.nextInt();
       int a[]=new int[n];
      for(i=0;i<n;i++)
      {
        a[i]=sc.nextInt();
        sum+=a[i];
      }
      i=(n+1)*(n)/2-sum;
      System.out.println("Missing number "+i);
     }
}