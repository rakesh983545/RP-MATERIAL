import java.util.Scanner;
public class Employee
{
    
    private int id;
    private String firstName;
    private String lastName;
    private int salary;
   // private int percent;
    
      public Employee(int id,String firstName,String lastName,int salary)
    {
        this.id=id;
    this.firstName=firstName;
    this.lastName=lastName;
    this.salary=salary;
    }   
    
    
    public int getID()
    {return id;}
    
    public String getFirstName()
    {return firstName;  }
    
    public String getLastName()
    {return lastName;}
    
   public String getName()
    {
        String Name;
        return Name=firstName+lastName;
    }
    
   public int getSalary()
    {   
        this.salary=salary;
        return  this.salary;
    }
    
    public void setSalary(int salary)
    {
        
    }
    
   public int getAnnualSalary()
    {   
        return salary*12; }
    
  public int raiseSalary(int percent)
    {    salary=salary+(salary*percent)/100;
        
       return salary;
       
 }
    
 public String toString()
    {  
   String s="Employee[id="+id+",name="+firstName+" "+lastName+",salary="+salary+"]";
    return s;
    }
    
  
    
  public static void main(String[] args)
    {
        Scanner emp1=new Scanner(System.in);
         System.out.println("id1 f1 l1 s1");
      int id1=emp1.nextInt();
     String f1=emp1.next();
      String l1=emp1.next();
        int s1=emp1.nextInt();
        Employee e1=new Employee(id1,f1,l1,s1);
     System.out.println(e1.toString());
        
    }
    
    
}