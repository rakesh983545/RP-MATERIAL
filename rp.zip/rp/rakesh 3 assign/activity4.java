import java.util.Scanner;
public class Keyboard
{
    int num1;
    float num2;
    String name;
    
  public static void main(String[] args)
    {
       
        Scanner key=new Scanner(System.in);
         System.out.println("Enter an integer:");
         int num1=key.nextInt();
         System.out.println("Enter a floating point number:");
      float num2=key.nextFloat();
       System.out.println("Enter your name:");
         String name=key.next();
         float sum=num1+num2;
      
      System.out.printf("Hi! %s, the sum of %d and %f is %f",name,num1,num2,sum);
        
    }
    
    
}