import java.util.Scanner;
public class InvoiceItem
{
    
    private String id;
    private String desc;
    private int qty;
    private double unitPrice;
    
      InvoiceItem(String id,String desc,int qty,double unitPrice)
    {
        this.id=id;
    this.desc=desc;
    this.qty=qty;
    this.unitPrice=unitPrice;
    }   
    
    
    public String getID()
    {return id;}
    
    public String getDesc()
    {return desc;  }
    
    public int getQty()
    {return qty;}
    
   public void setQty(int qty)
    {
      
    }
    
   public double getUnitPrice()
    {  return unitPrice;
    }
    
    public void setUnitPrice(double UnitPrice)
    {
        
    }
    
   public double getTotal()
    {
        double Total;
        return Total=unitPrice*qty;
        }
    

 public String toString()
    {  
    String s= "InvoiceItem[id="+id+",desc="+desc+",qty="+qty+",unitPrice="+unitPrice+"]";
    return s;
         }
    
  
    
  public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter id,desc,qty,unit price");
        String id1=sc.next();
        String desc1=sc.next();
        int qty1=sc.nextInt();
        double unit1=sc.nextDouble();
        InvoiceItem voice1=new InvoiceItem(id1,desc1,qty1,unit1);
        System.out.println(voice1.toString());
        
    }
    
    
}