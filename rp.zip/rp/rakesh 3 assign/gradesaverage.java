import java.util.Scanner;
public class GradeAverage
{
   public static void main(String[] args)
    {
        Scanner key=new Scanner(System.in);  
        System.out.printf("Enter the number of students:");
    int numStudents=key.nextInt();
   int sum=0;
    int[] grades=new int[numStudents];
    for(int i=0;i<numStudents;i++)
    {
        System.out.printf("Enter the grade for student %d:",i+1);
        grades[i]=key.nextInt();
        if(grades[i]>0 && grades[i]<101)
        {
                 sum=sum+grades[i];
        }
        else
        {i--;
         System.out.printf("Invalid grade, try again...");
            
        }
    }
       int avg=sum/numStudents-1;
            System.out.printf("The average is %d:",avg);
    }
            
}