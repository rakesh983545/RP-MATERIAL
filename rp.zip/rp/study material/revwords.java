package trainingday4;
import java.util.*;
public class revwords {
	public static void main(String args[])
	{
	String s,st="";
	int n,l,i;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter sentence");
	s=sc.nextLine();
	s=s+" ";
	for(i=0;i<s.length();i++)
	{
		if(s.charAt(i)==' ')
		{
			
				System.out.print(st+" ");
			st="";
		}
		else
		{
			st=s.charAt(i)+st;
		}
	}

}
}
