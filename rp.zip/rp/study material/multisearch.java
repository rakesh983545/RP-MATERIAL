import java.util.*;
public class multisearch {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int b,i,j,m,n;
		System.out.println("rows and column");
		m=sc.nextInt();
		n=sc.nextInt();
		int a[][]=new int[m][m];
		System.out.println("values in the array");
		for(i=0;i<m;i++)
			{
				for(j=0;j<n;j++)
					{
						a[i][j]=sc.nextInt();
					}
			}
		System.out.println("Enter search number");
		b=sc.nextInt();
		for(i=0;i<m;i++)
		{
			for(j=0;j<n;j++)
				{
					if(a[i][j]==b)
					{
						System.out.println("Found");
						return;
					}
				}
		}
		System.out.println("Not Found");
				
	}
}
