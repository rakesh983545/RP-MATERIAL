import java.util.*;

public class taxa{
 
   public static void main(String args[])
   {
	   float a,b,c;
	   Scanner sc=new Scanner(System.in);
	   a=sc.nextFloat();
	   if(a<=180000)
	   {
		   System.out.println("No tax payable");
	   }
	   else if(a>180000 && a<=300000)
		   System.out.println("tax ="+0.1*a);
	   else if(a>300000 && a<=500000)
		   System.out.println("tax ="+0.2*a);
	   else if(a>500000 && a<=1000000)
		   System.out.println("tax ="+0.3*a);
	   
   }
}