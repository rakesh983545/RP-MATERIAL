import java.util.Scanner;
public class Probeleven{

     public static void main(String []args){
        int n,i,j,temp;
        int a[]=new int[50];
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the numnber of elements:");
        n=sc.nextInt();
        System.out.println("Enter the elements:");
        for(i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        for(i=0;i<n;i++)
        {
            for (j = i + 1; j < n; j++) 
            {
                if (a[i] < a[j]) 
                {
                    temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            } 
        }
        for(i=0;i<3;i++)
        {
            System.out.println(a[i]);
        }
}
}