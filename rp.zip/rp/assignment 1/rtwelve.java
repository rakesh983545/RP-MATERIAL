import java.util.Scanner;
public class Probtwelve{

     public static void main(String []args){
        int n1,n2,n3,i,j,k,result;
        int a[]=new int[20];
        int b[]=new int[20];
        int c[]=new int[20];
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of first array:");
        n1=sc.nextInt();
        System.out.println("Enter the elements:");
        for(i=0;i<n1;i++)
        {
            a[i]=sc.nextInt();
        }
        System.out.println("Enter the size of second array:");
        n2=sc.nextInt();
        System.out.println("Enter the elements:");
        for(i=0;i<n2;i++)
        {
            b[i]=sc.nextInt();
        }
        System.out.println("Enter the size of third array:");
        n3=sc.nextInt();
        System.out.println("Enter the elements:");
        for(i=0;i<n3;i++)
        {
            c[i]=sc.nextInt();
        }
        i=0;
        j=0;
        k=0;
        while(i<n1&&j<n2&&k<n3)
        {
            if(a[i]==b[j]&&b[j]==c[k])
            {
                System.out.println(a[i]);
                i++;
                j++;
                k++;
            }
            else if(a[i] < b[j])
             i++;
            else if(b[j] < c[k])
             j++;
            else
             k++;
 
        }
}
}