import java.util.Scanner;
public class Probthree{

     public static void main(String []args){
        int a,b;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the first number:\n");
        a=sc.nextInt();
        System.out.println("Enter the second number:\n");
        b=sc.nextInt();
        a=a+b;
        b=a-b;
        a=a-b;
        System.out.println("After Swapping\n a:"+a+"\tb:"+b);
     }
}