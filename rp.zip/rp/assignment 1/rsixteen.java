import java.util.Scanner;
public class Probsixteen{

     public static void main(String []args){
        int n,i,j;
		int c=65;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value of n");
        n=sc.nextInt();
        for(i=0;i<=n;i++)
        {
            for(j=0;j<=i;j++)
            {
                System.out.print((char)c);
            }
			c++;
            System.out.println();
        }
        
}
}