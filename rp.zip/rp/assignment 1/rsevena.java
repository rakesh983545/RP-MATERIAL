import java.util.Scanner;
public class Probsevena{

     public static void main(String []args){
        int n,i,j,temp;
        int a[]=new int[100];
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the limit:");
        n=sc.nextInt();
        System.out.println("Enter the values");
        for(i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        for(i=0;i<n-1;i++)
        {
           for(j=0;j<n-i-1;j++)
           {
               if(a[j]>a[j+1])
               {
                   temp=a[j];
                   a[j]=a[j+1];
                   a[j+1]=temp;
               }
           }
        }
        for(i=0;i<n;i++)
        {
            System.out.println(a[i]);
        }
        
}
}