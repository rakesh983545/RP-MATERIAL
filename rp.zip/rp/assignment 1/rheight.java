package project;
import java.util.*;
public class Probeight {
	public static void main(String[] ag)
	{
	Scanner sc=new Scanner(System.in);
	int n,i;
	System.out.println("Enter the number of employees");
	n=sc.nextInt();
	Employee emp[]=new Employee[n];
	for(i=0;i<n;i++)
	{
		emp[i]=new Employee();
	}
    System.out.println("Enter the employee details");
    for(i=0;i<n;i++)
    {
    	System.out.println("Enter the Employee id for employee no "+(i+1));
    	emp[i].id=sc.nextInt();
    	System.out.println("Enter the Last Name for employee no "+(i+1));
    	emp[i].lastname=sc.next();
    	System.out.println("Enter the First Name for employee no "+(i+1));
    	emp[i].firstname=sc.next();
    	System.out.println("Enter the Middle Name for employee no "+(i+1));
    	emp[i].middlename=sc.next();
    	System.out.println("Enter the Department for employee no "+(i+1));
    	emp[i].department=sc.next();
    	System.out.println("Enter 'Yes' if Spanish known else 'No' for employee no "+(i+1));
    	emp[i].spanish=sc.next();
    	System.out.println("Enter the highest degree for employee no "+(i+1));
    	emp[i].degree=sc.next();
    	System.out.println("Enter the joining year for employee no "+(i+1));
    	emp[i].year=sc.nextInt();
    	emp[i].service=(2018-emp[i].year);
    }
    System.out.println("Employees slected for South America project");
    for(i=0;i<n;i++)
    {
    	if(((emp[i].spanish).equals("Yes"))&&emp[i].service>=5)
    	{
    		String a=emp[i].degree;
    		if(a.compareTo("BA")>=1)
    		{
    			System.out.println("Employee id="+emp[i].id);
    			System.out.println("Employee Last name="+emp[i].lastname);
    			System.out.println("Employee First name="+emp[i].firstname);
    			System.out.println("Employee Middle name="+emp[i].middlename);
    			System.out.println("Employee Department="+emp[i].department);
    		}
    	}
    }
}
}
