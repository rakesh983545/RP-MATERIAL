import java.util.Scanner;
public class Probseventeen{

     public static void main(String []args){
        int n,i,j;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value of n");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(j=i;j<n;j++)
            {
                System.out.print(" ");
            }
			for(j=1;j<=i;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
        
}
}