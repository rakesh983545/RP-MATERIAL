import java.util.Scanner;
public class Probten{

     public static void main(String []args){
        int n,i,sum;
        int a[]=new int[50];
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value of n");
        n=sc.nextInt();
        sum=(n*(n+1))/2;
        System.out.println("Enter the n-1 values");
        for(i=0;i<n-1;i++)
        {
            a[i]=sc.nextInt();
        }
        for(i=0;i<n-1;i++)
        {
            sum=sum-a[i];
        }
        System.out.println("The missing number:"+sum);
}
}