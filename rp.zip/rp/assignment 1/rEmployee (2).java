package project;

public class Employee {
	public int id;
	public String lastname;
	public String firstname;
	public String middlename;
	public String department;
	public String spanish;
	public String degree;
    int year;
    int service;
}
