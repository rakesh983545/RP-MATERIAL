import java.util.Scanner;
public class Probone{

     public static void main(String []args){
        int a,b,c,min;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the first number:\n");
        a=sc.nextInt();
        System.out.println("Enter the second number:\n");
        b=sc.nextInt();
        System.out.println("Enter the third number:\n");
        c=sc.nextInt();
        min=c < (a < b ? a:b) ? c:(a < b ? a:b);
        System.out.println("The smallest value is:"+min);
     }
}