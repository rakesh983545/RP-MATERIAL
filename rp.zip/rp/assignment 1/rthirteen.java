import java.util.Scanner;
public class Probthirteen{

     public static void main(String []args){
        int n,i,j;
        int a[]=new int[50];
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the numnber of elements:");
        n=sc.nextInt();
        System.out.println("Enter the elements:");
        for(i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        int m=n;
        for(i=0;i<n;i++)
        {
            if(a[i]==0)
            {
                for(j=i;j<n-1;j++)
                {
                    a[j]=a[j+1];
                }
                a[n]=0;
                n--;
            }
        }
        for(i=0;i<m;i++)
        {
            System.out.println(a[i]);
        }
}
}