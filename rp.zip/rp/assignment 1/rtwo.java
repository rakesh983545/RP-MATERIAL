import java.util.Scanner;
public class Probtwo{

     public static void main(String []args){
        int a,b,c;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the first number:\n");
        a=sc.nextInt();
        System.out.println("Enter the second number:\n");
        b=sc.nextInt();
        c=a;
        a=b;
        b=c;
        System.out.println("After Swapping\n a:"+a+"\tb:"+b);
     }
}