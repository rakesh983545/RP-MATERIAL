import java.util.Scanner;
public class Probfour{

     public static void main(String []args){
        int mark,count=0,i;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the marks of the 20 students");
        for(i=1;i<=20;i++)
        {
            mark=sc.nextInt();
            if(mark>=86)
            {
                count++;
            }
        }
        System.out.println("The number of students getting more than 86 is: "+count);
     }
}