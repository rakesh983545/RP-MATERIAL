package inherit;

public class Person {

	public static void main(String[] args) {
		person1 p= new person1("rakesh","bangalore");
		System.out.println("String:"+p.toString());
		
		Student s1=new Student("rakesh","bangalore","java",2010,15000);
		System.out.println("Program:"+s1.getProgram());
		System.out.println("Year:"+s1.getYear());
		System.out.println("Fee:"+s1.getFee());
		System.out.println("String:"+s1.toString());
		
		Staff s2=new Staff("manish","bangalore","capgemini",10000.00);
		System.out.println("School:"+s2.getSchool());
		System.out.println("Pay:"+s2.getPay());
		System.out.println("string:"+s2.toString());

	}

}
